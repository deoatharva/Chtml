package com.example.prolog

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class OutputActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_output)

        val webView = findViewById<WebView>(R.id.webViewOutput)
        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        val htmlCode = intent.getStringExtra("html_code")
        if (htmlCode != null) {
            webView.loadData(htmlCode, "text/html", "UTF-8")
        }
    }
}
